# Autopilot-Software
Contains any software designed by the autopilot sub-team for UAS operation.

Each application should be within its own folder which includes (at minimum) source code, built application, and any documentation.
